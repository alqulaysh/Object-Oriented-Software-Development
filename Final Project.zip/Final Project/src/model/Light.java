package model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * A light has a boolean state.
 */
public class Light implements Agent, CarInterface {

	private LightControlInter lightState;
	private List<Car> cars = new ArrayList<Car>();
	private CarInterface nextNSRoad;
	private CarInterface nextEWRoad;
	private CarInterface nextRoad;
	private double roadEnd;
	double greenLightTime;
	double yellowLightTime;

	Light(double roadEnd) {
		if (Math.random() <= 0.5) {
			lightState = new GreenTraficLight();
		} else {
			lightState = new RedTraficLight();
		}

		

		greenLightTime = getvarGreenTrafficLight();
		yellowLightTime = getvarYellowTrafficLight();
	}
	
	public static double YellowTrafficLight = 5.0;
	public static double getvarYellowTrafficLight() {
	return YellowTrafficLight;
}


	
		private static double GreenTrafficLight = 30.0;
		
		public static double getvarGreenTrafficLight() {
			return GreenTrafficLight;
		}

		
		
	public boolean getState() {
		return true;
	}

	public Color getColor() {
		return lightState.getColor();
	}

	public void run() {

		lightState = lightState.next();
		CarQueue.getServer().enqueue(
				CarQueue.getServer().currentTime()
						+ lightState.myTime(greenLightTime, yellowLightTime),
				this);

	}

	public void acceptCar(Car car, double frontPosition) {
		
	}

	public void removeCar(Car car) {
		
	}

	public List<Car> getCars() {
		return cars;
	}

	public CarInterface getNextRoad(Car c) {
		if (c.getNSCar())
			return getNextNorthSouthRoad();
		else
			return getNextEastWestRoad();
	}

	public void setNextRoad(CarInterface r) {
		nextRoad = r;
	}

	@Override
	public void setNextNorthSouthRoad(CarInterface road) {
		// TODO Auto-generated method stub
		nextNSRoad = road;
	}

	@Override
	public void setNextEastWestRoad(CarInterface road) {
		// TODO Auto-generated method stub
		nextEWRoad = road;
	}

	@Override
	public CarInterface getNextNorthSouthRoad() {
		// TODO Auto-generated method stub
		return nextNSRoad;
	}

	@Override
	public CarInterface getNextEastWestRoad() {
		// TODO Auto-generated method stub
		return nextEWRoad;
	}

	@Override
	public double getRoadClosed() {
		// TODO Auto-generated method stub
		return roadEnd;
	}

	@Override
	public double distanceToStop(Car car, double fromPosition) {
		// TODO Auto-generated method stub
		double obstacleDist = lightState.distanceToObstacle(car, fromPosition,
				this);

		double obstacle = CarFactory.distanceToCarBack(car, fromPosition, cars,
				(CarInterface) this);
		obstacle = Math.min(obstacle, obstacleDist);
		if (obstacle == Double.POSITIVE_INFINITY) {
			obstacle = (getRoadClosed() - fromPosition + getNextRoad(car)
					.distanceToStop(car, 0));
		}

		return obstacle;
	}

	@Override
	public double currentTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void enqueue(double waketime, Agent thing) {
		// TODO Auto-generated method stub
		
	}

	

	@Override
	public void run(double duration) {
		// TODO Auto-generated method stub
		
	}
}
