package model;

import java.util.List;

/**
 * A road holds cars.
 */
public abstract class Road implements CarInterface {

	public abstract List<Car> getCars();

}
