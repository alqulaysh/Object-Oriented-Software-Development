package model;

import java.awt.Color;

public abstract class LightControlInter {
	public abstract String getState();

	public abstract Color getColor();

	public abstract LightControlInter next();

	public abstract double myTime(double greenLight, double yellowLight);

	public abstract double distanceToObstacle(Car car, double frontPosition, Light light);
}
