package model;

import java.util.ArrayList;
import java.util.List;

public final class RoadFromNorthToSouth extends Road{
	private List<Car> myCars = new ArrayList<Car>();
	private CarInterface nextNorthSouth;
	private CarInterface nextRoad;
	private double roadClosed;

	RoadFromNorthToSouth(double roadEnd) {
		if (roadEnd < 0.0)
			throw new IllegalArgumentException();
		else
			roadClosed = roadEnd;
	}	

	@Override
	public List<Car> getCars() {
		return myCars;
	}

	@Override
	public void setNextNorthSouthRoad(CarInterface road) {
		nextNorthSouth = road;
		nextRoad = road;
	}

	@Override
	public void acceptCar(Car car, double frontPosition) {
		if (car == null)
			throw new IllegalArgumentException();
		myCars.remove(car);
		if (frontPosition > getRoadClosed())
			getNextRoad(car).acceptCar(car, frontPosition - getRoadClosed());
		else {
			car.setCurrentRoad(this);
			car.setFrontPosition(frontPosition);
			myCars.add(car);
			CarQueue.getServer().enqueue(
					CarQueue.getServer().currentTime()
							+ ParameterManager.getvarTimeStep(), car);
		}
	}

	@Override
	public CarInterface getNextRoad(Car c) {
		return nextNorthSouth;
	}

	@Override
	public void setNextRoad(CarInterface r) {
		nextRoad = r;

	}

	@Override
	public void setNextEastWestRoad(CarInterface road) {
		// TODO Auto-generated method stub
		throw new IllegalArgumentException();
	}

	@Override
	public CarInterface getNextNorthSouthRoad() {
		// TODO Auto-generated method stub
		return nextNorthSouth;
	}

	@Override
	public CarInterface getNextEastWestRoad() {
		// TODO Auto-generated method stub
		throw new IllegalArgumentException();
	}

	@Override
	public double getRoadClosed() {
		// TODO Auto-generated method stub
		return roadClosed;
	}

	@Override
	public double distanceToStop(Car car, double fromPosition) {
		// TODO Auto-generated method stub
		double obstacle = CarFactory.distanceToCarBack(car, fromPosition,
				myCars, this);
		if (obstacle == Double.POSITIVE_INFINITY)
			obstacle = (getRoadClosed() - fromPosition)
					+ getNextRoad(car).distanceToStop(car, 0);
		return obstacle;
	}

	@Override
	public double currentTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void enqueue(double waketime, Agent thing) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void run(double duration) {
		// TODO Auto-generated method stub
		
	}

}
