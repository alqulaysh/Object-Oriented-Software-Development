package model;

import java.util.ArrayList;
import java.util.List;

public final class RoadFromEastToWest extends Road implements
		CarInterface {
	private List<Car> simCars = new ArrayList<Car>();
	private CarInterface nextEastWestRoad;
	private CarInterface nextRoad;
	private double roadClosed;

	RoadFromEastToWest(double roadClosed) {
		if (roadClosed < 0.0) {
			throw new IllegalArgumentException();
		} else {
			this.roadClosed = roadClosed;
		}

	}

	@Override
	public List<Car> getCars() {
		return simCars;
	}

	@Override
	public void acceptCar(Car car, double frontPosition) {
		if (car == null)
			throw new IllegalArgumentException();
		simCars.remove(car);
		if (frontPosition > getRoadClosed())
			getNextRoad(car).acceptCar(car, frontPosition - getRoadClosed());
		else {
			car.setCurrentRoad(this);
			car.setFrontPosition(frontPosition);
			simCars.add(car);
			CarQueue.getServer().enqueue(
					CarQueue.getServer().currentTime()
							+ ParameterManager.getvarTimeStep(), car);
		}

	}

	@Override
	public CarInterface getNextRoad(Car c) {
		return nextEastWestRoad;
	}

	@Override
	public void setNextRoad(CarInterface r) {
		nextRoad = r;

	}

	@Override
	public void setNextNorthSouthRoad(CarInterface road) {
		// TODO Auto-generated method stub
		throw new IllegalArgumentException();
	}

	@Override
	public void setNextEastWestRoad(CarInterface road) {
		// TODO Auto-generated method stub
		nextEastWestRoad = road;
		nextRoad = road;
	}

	@Override
	public CarInterface getNextNorthSouthRoad() {
		// TODO Auto-generated method stub
		throw new IllegalArgumentException();
	}

	@Override
	public CarInterface getNextEastWestRoad() {
		// TODO Auto-generated method stub
		return nextEastWestRoad;
	}

	@Override
	public double getRoadClosed() {
		// TODO Auto-generated method stub
		return roadClosed;
	}

	@Override
	public double distanceToStop(Car car, double fromPosition) {
		// TODO Auto-generated method stub
		double obstacle = CarFactory.distanceToCarBack(car, fromPosition,
				simCars, (CarInterface) this);
		if (obstacle == Double.POSITIVE_INFINITY)
			obstacle = (getRoadClosed() - fromPosition)
					+ getNextRoad(car).distanceToStop(car, 0);
		return obstacle;
	}

	@Override
	public double currentTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void enqueue(double waketime, Agent thing) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void run(double duration) {
		// TODO Auto-generated method stub
		
	}
}
