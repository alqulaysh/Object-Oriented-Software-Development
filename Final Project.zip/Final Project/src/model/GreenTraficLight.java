package model;

import java.awt.Color;

public class GreenTraficLight extends LightControlInter {

	
	public String getState() {
		return "GREEN";
	}


	public Color getColor() {
		return Color.GREEN;
	}

	
	public LightControlInter next() {
		return new YellowTraficLight();
	}

	
	public double distanceToObstacle(Car car, double frontPosition, Light light) {
		// TODO Auto-generated method stub
		double distance = Double.POSITIVE_INFINITY;
		if (car.getNSCar() && car.getCurrentRoad() != light) {
			distance = car.getCurrentRoad().getRoadClosed() - frontPosition;
		}
		return distance;
	}

	
	public double myTime(double greenLight, double yellowLight) {
		// TODO Auto-generated method stub
		return (greenLight- yellowLight);
		
	}

}
