package model;

public enum TrafficPattern
{
	ALTERNATING,
	SIMPLE;
}
      