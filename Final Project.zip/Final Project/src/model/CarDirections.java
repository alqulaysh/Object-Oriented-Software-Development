package model;

import java.util.ArrayList;
import java.util.List;

public class CarDirections implements CarInterface, Agent {

	private List<Car> cars = new ArrayList<Car>();
	private CarInterface nextEastWestRoad;
	private CarInterface nextNorthSouthRoad;
	private CarInterface nextRoad;
	private double roadEnd;
	private double generationRate;

	CarDirections(double roadEnd) {
		
	}

	@Override
	public void run() {
		Car car = CarFactory.newCar();
		car.setCurrentRoad(nextRoad);
		car.setNSCar(getNSCarDirection());
		if (nextRoad.distanceToStop(car, 1) >= 1) {
			nextRoad.acceptCar(car, 1);
		}
		CarQueue.getServer().enqueue(
				CarQueue.getServer().currentTime() + generationRate, this);
		generationRate = getvarEntryRate();
	}

	public boolean getNSCarDirection() {
		if (this.nextEastWestRoad == null)
			return true;
		else
			return false;
	}

	
		public static double varEntryRate = 10;
		public static double getvarEntryRate() {
			return varEntryRate;
		}

	
	@Override
	public void acceptCar(Car car, double frontPosition) {
		

	}

	

	@Override
	public CarInterface getNextRoad(Car c) {
		if (c.getNSCar()) {
			return getNextNorthSouthRoad();
		} else {
			return getNextEastWestRoad();
		}
	}

	@Override
	public void setNextRoad(CarInterface r) {
		nextRoad = r;
	}

	@Override
	public void setNextNorthSouthRoad(CarInterface road) {
		// TODO Auto-generated method stub
		nextNorthSouthRoad = road;
		nextRoad = road;
	}

	@Override
	public void setNextEastWestRoad(CarInterface road) {
		// TODO Auto-generated method stub
		nextEastWestRoad = road;
		nextRoad = road;
	}

	@Override
	public CarInterface getNextNorthSouthRoad() {
		// TODO Auto-generated method stub
		return nextNorthSouthRoad;
	}

	@Override
	public CarInterface getNextEastWestRoad() {
		// TODO Auto-generated method stub
		return nextEastWestRoad;
	}

	@Override
	public double getRoadClosed() {
		// TODO Auto-generated method stub
		return roadEnd;
	}

	@Override
	public double distanceToStop(Car car, double fromPosition) {
		return 0.0;
	}

	@Override
	public double currentTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void enqueue(double waketime, Agent thing) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run(double duration) {
		// TODO Auto-generated method stub
		
	}

	
	

}
