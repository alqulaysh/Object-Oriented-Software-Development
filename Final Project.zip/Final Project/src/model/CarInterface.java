package model;

import java.util.List;

public interface CarInterface {
	public void setNextNorthSouthRoad(CarInterface road);

	public void setNextEastWestRoad(CarInterface road);

	public CarInterface getNextNorthSouthRoad();

	public CarInterface getNextEastWestRoad();

	public double getRoadClosed();

	public void acceptCar(Car car, double frontPosition);

	public double distanceToStop(Car car, double fromPosition);

	public CarInterface getNextRoad(Car c);

	public void setNextRoad(CarInterface r);
	
	public double currentTime();

	public void enqueue(double waketime, Agent thing);


	public void run(double duration);
}
