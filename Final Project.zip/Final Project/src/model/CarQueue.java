package model;

import java.util.List;
import java.util.NoSuchElementException;

public class CarQueue implements CarInterface {

	private static final class Service {

		final double earlyThrough;
		final Agent myAgent;
		Service upComingRoute;

		public Service(double earlyThrough, Agent myAgent, Service upComingRoute) {
			this.earlyThrough = earlyThrough;
			this.myAgent = myAgent;
			this.upComingRoute = upComingRoute;
		}
	}

	private static double currentTime;
	private static int size;
	private static Service head = new Service(0, null, null);
	private static CarInterface timeServerQueue;

	public static CarInterface getServer() {
		if (timeServerQueue == null) {
			synchronized (CarQueue.class) {
				if (timeServerQueue == null) {
					timeServerQueue = new CarQueue();
				}
			}
		}
		return timeServerQueue;
	}

	public double currentTime() {
		return currentTime;
	}

	public void enqueue(double earlyThrough, Agent myAgent)
			{
		Service prevElement = head;
		while ((prevElement.upComingRoute != null)
				&& (prevElement.upComingRoute.earlyThrough <= earlyThrough)) {
			prevElement = prevElement.upComingRoute;
		}
		Service newElement = new Service(earlyThrough, myAgent,
				prevElement.upComingRoute);
		prevElement.upComingRoute = newElement;
		size++;
	}

	Agent dequeue() {
		
			Agent realValue = head.upComingRoute.myAgent;
			head.upComingRoute = head.upComingRoute.upComingRoute;
			size--;
			return realValue;
		}
	

	int size() {
		return size;
	}

	boolean empty() {
		return size() == 0;
	}

	public void reset() {
		
	}

	public void run(double duration) {
		double endtime = currentTime + duration;
		while ((!empty()) && (head.upComingRoute.earlyThrough <= endtime)) {
			currentTime = head.upComingRoute.earlyThrough;
			dequeue().run();
		}
		currentTime = endtime;
	}

	@Override
	public void setNextNorthSouthRoad(CarInterface road) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setNextEastWestRoad(CarInterface road) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public CarInterface getNextNorthSouthRoad() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CarInterface getNextEastWestRoad() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getRoadClosed() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void acceptCar(Car car, double frontPosition) {
		// TODO Auto-generated method stub
		
	}

	

	@Override
	public double distanceToStop(Car car, double fromPosition) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public CarInterface getNextRoad(Car c) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setNextRoad(CarInterface r) {
		// TODO Auto-generated method stub
		
	}
}
