package model;

import java.util.ArrayList;
import java.util.List;

public final class CarFactory implements CarInterface{

	
	private List<Car> cars = new ArrayList<Car>();
	private double roadEnd;
	private CarInterface nextRoad;
	private CarInterface nextEWRoad;
	private CarInterface nextNSRoad;

	
	
	
	public static Car newCar() {
		return new Car(getvarCarLength(), getVelocity(),
				getbreak(), getstop());
	}

	public CarFactory(double roadEnd) {
		
	}
		
	public static CarInterface newEWRoad() {
		return new RoadFromEastToWest(roadLength);
	}

	public static CarInterface newNSRoad() {
		return new RoadFromNorthToSouth(roadLength);
	}

	
		public static double roadLength = 250;
		

		public static double getRoadLength() {
			return roadLength;
		}

		
	
	public static CarInterface newSink() {
		return new CarFactory(1);
	}

	public static CarInterface newSource() {
		return new CarDirections(0);
	}

	public static CarInterface newLight() {
		return new Light(getvarIntersectionLength());
	}
	
		public static double varIntersectionLength = 10;
		
		public static double getvarIntersectionLength() {
			return varIntersectionLength;
		}

	
		public static double getbreak() {
			return 10.0;
		}

		public static double getstop() {
			return 5.0;
		}	

		public static double getVelocity() {
			return 10;
		}
		public static double CCarLength = 10;
		

		public static double getvarCarLength() {
			return CCarLength;
		}


	static double distanceToCarBack(Car car, double fromPosition,
			List<Car> cars, CarInterface road) {
		double carBackPosition = Double.POSITIVE_INFINITY;
		if (car.getCurrentRoad() == road) {
			for (Car c : cars)
				if (c != car && c.getBackPosition() >= fromPosition
						&& c.getBackPosition() < carBackPosition) {
					carBackPosition = c.getBackPosition() - 1;
				}
		
		}
		return carBackPosition - fromPosition
			;
	}



	@Override
	public void setNextNorthSouthRoad(CarInterface road) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void setNextEastWestRoad(CarInterface road) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public CarInterface getNextNorthSouthRoad() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public CarInterface getNextEastWestRoad() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public double getRoadClosed() {
		// TODO Auto-generated method stub
		return 0;
	}



	@Override
	public void acceptCar(Car car, double frontPosition) {
		// TODO Auto-generated method stub
		
	}





	@Override
	public double distanceToStop(Car car, double fromPosition) {
		// TODO Auto-generated method stub
		return 0;
	}



	@Override
	public CarInterface getNextRoad(Car c) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void setNextRoad(CarInterface r) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public double currentTime() {
		// TODO Auto-generated method stub
		return 0;
	}



	@Override
	public void enqueue(double waketime, Agent thing) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void run(double duration) {
		// TODO Auto-generated method stub
		
	}
	

		
		
}
