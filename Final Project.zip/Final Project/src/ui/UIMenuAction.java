package ui;

public interface UIMenuAction {
	public void run();
}
