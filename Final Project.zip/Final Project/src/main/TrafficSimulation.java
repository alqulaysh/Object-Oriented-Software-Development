
//Aziz Alqulaysh

package main;

import model.ParameterManager;
import model.Model;
import model.swing.SwingAnimatorBuilder;
import parser.JSONFileParameterParser;


/**
 * A static class to demonstrate the visualization aspect of simulation.
 */
public class TrafficSimulation {
	private TrafficSimulation() {
	}

	public static void main(String[] args) {

		JSONFileParameterParser.loadParameters("simulationparameters.json");
		Model m = new Model(new SwingAnimatorBuilder(), ParameterManager.rows, ParameterManager.columns);

		m.run(ParameterManager.getSimulationRunTime());

		m.dispose();

		System.exit(0);
		
	}
}
